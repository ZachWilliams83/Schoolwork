#include <stdio.h>

int main(){
	char chr = 78;
	printf("The character having ASCII value 78 is %c.\n", chr);
	return 0;
}
