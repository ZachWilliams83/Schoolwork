#include <stdio.h>

int main()
{
	//printf() displays the string inside the quotation
	// \n adds a newline
	printf("Hello World!\n");
	printf("Hello, \nUMaine!\n");

	printf("    *\n   **\n  ***\n ****\n*****\n\n");
	printf("  *****\n   *** \n    *  \n\n");
	printf("|\\\n| \\\n|  \\\n|___\\\n\n");
	printf("     *   *       *\n\n  *        *   *\n\n *\n\n");
	return 0;
}
