
public class Patient {
	public int IdNumber;
	public double caffeine;
	
	public Patient(int IdNumber, double caffeine) {
		this.IdNumber = IdNumber;
		this.caffeine = caffeine;
	}
}
